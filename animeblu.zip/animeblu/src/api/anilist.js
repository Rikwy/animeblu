const ENDPOINT = 'https://graphql.anilist.co'
const cache = new Map()

const FIELDS = `
  id title { romaji english native } description(asHtml: false) bannerImage
  coverImage { extraLarge large color } averageScore seasonYear season episodes duration
  genres status format studios(isMain: true) { nodes { name } }
  streamingEpisodes { title thumbnail url site } trailer { id site }`

async function gql(query, variables = {}) {
  const key = JSON.stringify([query, variables])
  if (cache.has(key)) return cache.get(key)
  const res = await fetch(ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ query, variables })
  })
  if (!res.ok) throw new Error(`AniList error ${res.status}`)
  const json = await res.json()
  if (json.errors) throw new Error(json.errors[0].message)
  cache.set(key, json.data)
  return json.data
}

export function currentSeason(d = new Date()) {
  const m = d.getMonth()
  const season = m < 3 ? 'WINTER' : m < 6 ? 'SPRING' : m < 9 ? 'SUMMER' : 'FALL'
  return { season, year: d.getFullYear() }
}

export const titleOf = (a) => a?.title?.english || a?.title?.romaji || a?.title?.native || ''
export const scoreOf = (a) => (a?.averageScore ? (a.averageScore / 10).toFixed(1) : null)
export const cleanDesc = (s = '') => (s || '').replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, '').trim()

export async function getHome() {
  const { season, year } = currentSeason()
  const q = `query($season: MediaSeason, $year: Int) {
    trending: Page(perPage: 20) { media(type: ANIME, sort: TRENDING_DESC, isAdult: false) { ...F } }
    popular: Page(perPage: 20) { media(type: ANIME, sort: POPULARITY_DESC, isAdult: false) { ...F } }
    seasonal: Page(perPage: 20) { media(type: ANIME, season: $season, seasonYear: $year, sort: POPULARITY_DESC, isAdult: false) { ...F } }
    top: Page(perPage: 20) { media(type: ANIME, sort: SCORE_DESC, isAdult: false) { ...F } }
  }
  fragment F on Media { ${FIELDS} }`
  const d = await gql(q, { season, year })
  return { trending: d.trending.media, popular: d.popular.media, seasonal: d.seasonal.media, top: d.top.media }
}

export async function getAnime(id) {
  const q = `query($id: Int) { Media(id: $id, type: ANIME) { ${FIELDS}
    recommendations(perPage: 12, sort: RATING_DESC) { nodes { mediaRecommendation { ${FIELDS} } } } } }`
  const d = await gql(q, { id: Number(id) })
  return d.Media
}

export async function searchAnime({ search, genre, sort = 'POPULARITY_DESC', page = 1 }) {
  const q = `query($search: String, $genre: String, $sort: [MediaSort], $page: Int) {
    Page(page: $page, perPage: 24) { pageInfo { hasNextPage } media(type: ANIME, search: $search, genre: $genre, sort: $sort, isAdult: false) { ${FIELDS} } } }`
  const d = await gql(q, { search: search || undefined, genre: genre || undefined, sort: [sort], page })
  return { items: d.Page.media, hasNext: d.Page.pageInfo.hasNextPage }
}

export async function getGenres() {
  const d = await gql('{ GenreCollection }')
  return d.GenreCollection.filter((g) => g !== 'Hentai')
}
