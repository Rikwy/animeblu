import { Link } from 'react-router-dom'
import { useApp } from '../context/AppContext.jsx'
import { titleOf } from '../api/anilist.js'

export default function History() {
  const { history } = useApp()
  const list = Object.values(history).sort((a, b) => b.updatedAt - a.updatedAt)
  return (
    <div className="page">
      <h1 className="page-title">سجل المشاهدة</h1>
      {list.length === 0 && <div className="empty">لا يوجد سجل مشاهدة بعد.</div>}
      <div className="list">
        {list.map((h) => (
          <Link key={h.anime.id + ':' + h.ep} to={`/watch/${h.anime.id}/${h.ep}`} className="hist glass">
            <img src={h.anime.coverImage?.large} alt="" />
            <div>
              <b>{titleOf(h.anime)}</b>
              <span>الحلقة {h.ep} · {new Date(h.updatedAt).toLocaleDateString('ar')}</span>
              <div className="bar"><i style={{ width: (h.duration ? (h.time / h.duration) * 100 : 0) + '%' }} /></div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}
