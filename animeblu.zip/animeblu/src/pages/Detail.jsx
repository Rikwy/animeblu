import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getAnime, titleOf } from '../api/anilist.js'
import Hero from '../components/Hero.jsx'
import EpisodeRow from '../components/EpisodeRow.jsx'
import Section from '../components/Section.jsx'
import AnimeCard from '../components/AnimeCard.jsx'

export default function Detail() {
  const { id } = useParams()
  const [a, setA] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    setA(null); setError('')
    getAnime(id).then((r) => { setA(r); document.title = `${titleOf(r)} — Animeblu` }).catch((e) => setError(e.message))
    window.scrollTo(0, 0)
  }, [id])

  if (error) return <div className="empty">{error}</div>
  if (!a) return <div className="hero skeleton" />
  const recs = a.recommendations?.nodes.map((n) => n.mediaRecommendation).filter(Boolean) || []
  const studio = a.studios?.nodes?.[0]?.name

  return (
    <div className="page">
      <Hero anime={a} />
      <div className="info glass">
        <div><span>الحالة</span><b>{a.status}</b></div>
        <div><span>الصيغة</span><b>{a.format}</b></div>
        <div><span>المدة</span><b>{a.duration ? `${a.duration} د` : '—'}</b></div>
        <div><span>الاستوديو</span><b>{studio || '—'}</b></div>
        <div><span>التصنيفات</span><b>{a.genres.join('، ')}</b></div>
      </div>
      <section className="section">
        <div className="section-head"><h2>الحلقات</h2></div>
        <EpisodeRow anime={a} />
      </section>
      {a.trailer?.site === 'youtube' && (
        <section className="section">
          <div className="section-head"><h2>الإعلان</h2></div>
          <div className="player"><iframe title="trailer" src={`https://www.youtube.com/embed/${a.trailer.id}`} allowFullScreen /></div>
        </section>
      )}
      {recs.length > 0 && <Section title="قد يعجبك">{recs.map((r) => <AnimeCard key={r.id} anime={r} />)}</Section>}
      <Link to="/explore" className="btn glass center">استكشاف المزيد</Link>
    </div>
  )
}
