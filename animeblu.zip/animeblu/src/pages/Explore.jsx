import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { searchAnime, getGenres } from '../api/anilist.js'
import AnimeCard from '../components/AnimeCard.jsx'

const SORTS = [
  ['POPULARITY_DESC', 'الأكثر شعبية'],
  ['SCORE_DESC', 'الأعلى تقييماً'],
  ['TRENDING_DESC', 'الرائج'],
  ['START_DATE_DESC', 'الأحدث']
]

export default function Explore({ mode }) {
  const [params] = useSearchParams()
  const q = mode === 'search' ? params.get('q') || '' : ''
  const [genres, setGenres] = useState([])
  const [genre, setGenre] = useState('')
  const [sort, setSort] = useState(mode === 'popular' ? 'POPULARITY_DESC' : 'TRENDING_DESC')
  const [items, setItems] = useState([])
  const [page, setPage] = useState(1)
  const [hasNext, setHasNext] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => { getGenres().then(setGenres).catch(() => {}) }, [])
  useEffect(() => { setPage(1); setItems([]) }, [q, genre, sort, mode])

  useEffect(() => {
    let off = false
    setLoading(true)
    searchAnime({ search: q, genre, sort: q ? 'SEARCH_MATCH' : sort, page })
      .then((r) => { if (!off) { setItems((p) => (page === 1 ? r.items : [...p, ...r.items])); setHasNext(r.hasNext); setError('') } })
      .catch((e) => !off && setError(e.message))
      .finally(() => !off && setLoading(false))
    return () => { off = true }
  }, [q, genre, sort, page])

  const title = mode === 'search' ? `نتائج البحث: ${q}` : mode === 'popular' ? 'الأكثر مشاهدة' : 'استكشاف الأنمي'
  return (
    <div className="page">
      <h1 className="page-title">{title}</h1>
      {mode !== 'search' && (
        <div className="filters">
          <select className="glass" value={genre} onChange={(e) => setGenre(e.target.value)}>
            <option value="">كل التصنيفات</option>
            {genres.map((g) => <option key={g} value={g}>{g}</option>)}
          </select>
          <select className="glass" value={sort} onChange={(e) => setSort(e.target.value)}>
            {SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </div>
      )}
      {error && <div className="empty">{error}</div>}
      <div className="grid">{items.map((a) => <AnimeCard key={a.id} anime={a} />)}</div>
      {!loading && !error && items.length === 0 && <div className="empty">لا توجد نتائج.</div>}
      {loading && <div className="empty">جارٍ التحميل...</div>}
      {hasNext && !loading && <button className="btn glass center" onClick={() => setPage((p) => p + 1)}>عرض المزيد</button>}
    </div>
  )
}
