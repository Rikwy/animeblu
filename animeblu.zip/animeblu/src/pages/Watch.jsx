import { useCallback, useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getAnime, titleOf } from '../api/anilist.js'
import { useApp } from '../context/AppContext.jsx'
import VideoPlayer from '../components/VideoPlayer.jsx'
import EpisodeRow from '../components/EpisodeRow.jsx'

export default function Watch() {
  const { id, ep } = useParams()
  const { sources, setSource, saveProgress, history } = useApp()
  const [anime, setAnime] = useState(null)
  const [file, setFile] = useState({})
  const [url, setUrl] = useState('')
  const [sourceIndex, setSourceIndex] = useState(0)
  const [sourceMessage, setSourceMessage] = useState('')

  useEffect(() => { getAnime(id).then(setAnime).catch(() => {}) }, [id])
  useEffect(() => { fetch('/sources.json').then((r) => r.json()).then(setFile).catch(() => {}) }, [])
  useEffect(() => { window.scrollTo(0, 0) }, [id, ep])

  const localEntry = sources[`${id}:${ep}`]
  const fileEntry = file?.[id]?.[ep]
  const candidates = [...(localEntry == null ? [] : (Array.isArray(localEntry) ? localEntry : [localEntry])), ...(fileEntry == null ? [] : (Array.isArray(fileEntry) ? fileEntry : [fileEntry]))]
    .filter((value, index, all) => typeof value === 'string' && /^https?:\/\//i.test(value) && all.indexOf(value) === index)
  const src = candidates[sourceIndex] || ''
  useEffect(() => { setSourceIndex(0); setSourceMessage('') }, [id, ep])
  const tryNextSource = useCallback(() => {
    setSourceIndex((current) => {
      if (current + 1 < candidates.length) { setSourceMessage(`تعذّر المصدر السابق؛ نجرب المصدر ${current + 2} من ${candidates.length}`); return current + 1 }
      setSourceMessage('تعذّر تشغيل جميع المصادر المتاحة لهذه الحلقة.')
      return current
    })
  }, [candidates.length])
  const start = history[`${id}:${ep}`]?.time || 0
  const onProgress = useCallback((t, d) => anime && saveProgress(anime, Number(ep), t, d), [anime, ep, saveProgress])

  const n = Number(ep)
  const total = anime?.episodes || 0
  const legalSearch = anime ? `https://www.justwatch.com/sa/search?q=${encodeURIComponent(titleOf(anime))}` : 'https://www.justwatch.com/sa'
  const previews = (anime?.streamingEpisodes || []).filter((item) => item?.url && item?.title)

  return (
    <div className="page">
      <h1 className="page-title">{anime ? titleOf(anime) : '...'} — الحلقة {ep}</h1>
      {src ? (
        <VideoPlayer key={`${src}-${sourceIndex}`} src={src} startAt={start} onProgress={onProgress} onFatal={tryNextSource} />
      ) : (
        <div className="player empty-player glass">
          <p>لا يوجد مصدر فيديو متاح لهذه الحلقة.</p>
          <p className="muted">AniList يوفّر بيانات الأنمي فقط. أضف روابط HLS أو MP4 لمحتوى تملك حق استخدامه، ويمكن إضافة أكثر من مصدر ليجرّب Animeblu البديل تلقائياً.</p>
        </div>
      )}
      {!src && <section className="legal-sources glass">
        <div className="legal-copy">
          <h2>اعثر على مشاهدة رسمية</h2>
          <p className="muted">نبحث لك عن أماكن توفر هذا الأنمي في السعودية. قد تختلف الإتاحة حسب الاشتراك والمنطقة؛ لن نعرض روابط تشغيل غير موثوقة.</p>
        </div>
        <a className="btn primary" href={legalSearch} target="_blank" rel="noreferrer">البحث عن {anime ? titleOf(anime) : 'الأنمي'} على JustWatch</a>
        {previews.length > 0 && <div className="preview-links">
          <strong>مقاطع ومعاينات من AniList</strong>
          {previews.slice(0, 4).map((item, i) => <a key={`${item.url}-${i}`} href={item.url} target="_blank" rel="noreferrer">{item.title} — {item.site || 'فتح المعاينة'}</a>)}
          <small className="muted">هذه معاينات قد لا تكون حلقات كاملة.</small>
        </div>}
      </section>}
      <form className="src-form glass" onSubmit={(e) => { e.preventDefault(); if (url.trim()) { setSource(id, ep, url.trim()); setUrl(''); setSourceIndex(0); setSourceMessage('تمت إضافة المصدر. سيُجرّب تلقائياً إذا تعذّر المصدر الحالي.') } }}>
        <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="أضف رابط HLS أو MP4 مرخّصاً؛ يمكن إضافة عدة روابط بالتتابع" dir="ltr" />
        <button className="btn primary" type="submit">تعيين المصدر</button>
      </form>
      {sourceMessage && <p className="muted" role="status">{sourceMessage}</p>}
      {candidates.length > 1 && <p className="muted">مصدر {Math.min(sourceIndex + 1, candidates.length)} من {candidates.length}</p>}
      <div className="btns">
        {n > 1 && <Link className="btn glass" to={`/watch/${id}/${n - 1}`}>الحلقة السابقة</Link>}
        {(!total || n < total) && <Link className="btn glass" to={`/watch/${id}/${n + 1}`}>الحلقة التالية</Link>}
        {anime && <Link className="btn glass" to={`/anime/${id}`}>صفحة الأنمي</Link>}
      </div>
      {anime && <section className="section"><div className="section-head"><h2>كل الحلقات</h2></div><EpisodeRow anime={anime} /></section>}
    </div>
  )
}
