import { useCallback, useEffect, useMemo, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { ExternalLink, PlayCircle, Plus, Trash2 } from 'lucide-react'
import { getAnime, titleOf } from '../api/anilist.js'
import { useApp } from '../context/AppContext.jsx'
import VideoPlayer from '../components/VideoPlayer.jsx'
import EpisodeRow from '../components/EpisodeRow.jsx'

function episodeNumber(item, fallback) {
  const text = `${item?.title || ''} ${item?.url || ''}`
  const match = text.match(/(?:episode|ep|الحلقة|#)\s*0*(\d{1,4})/i) || text.match(/\/(\d{1,4})(?:\/?$|[?#])/)
  return match ? Number(match[1]) : fallback
}

export default function Watch() {
  const { id, ep } = useParams()
  const { sources, setSource, saveProgress, history } = useApp()
  const [anime, setAnime] = useState(null)
  const [file, setFile] = useState({})
  const [url, setUrl] = useState('')
  const [sourceError, setSourceError] = useState('')

  useEffect(() => { getAnime(id).then(setAnime).catch(() => {}) }, [id])
  useEffect(() => { fetch('/sources.json').then((r) => r.json()).then(setFile).catch(() => {}) }, [])
  useEffect(() => { window.scrollTo(0, 0) }, [id, ep])

  const key = `${id}:${ep}`
  const saved = sources[key]
  const configured = saved || file?.[id]?.[ep] || []
  const playableSources = useMemo(() => (Array.isArray(configured) ? configured : [configured]).filter(Boolean), [configured])
  const start = history[key]?.time || 0
  const onProgress = useCallback((t, d) => anime && saveProgress(anime, Number(ep), t, d), [anime, ep, saveProgress])
  const n = Number(ep)
  const total = anime?.episodes || 0

  const officialLinks = useMemo(() => {
    if (!anime?.streamingEpisodes?.length) return []
    return anime.streamingEpisodes
      .map((item, i) => ({ ...item, number: episodeNumber(item, i + 1) }))
      .filter((item) => item.number === n && item.url)
      .slice(0, 5)
  }, [anime, n])

  const addSource = (event) => {
    event.preventDefault()
    const values = url.split(/\n|,/).map((v) => v.trim()).filter(Boolean)
    const valid = values.filter((v) => /^https:\/\/.+/i.test(v) && /\.(m3u8|mp4)(?:$|[?#])/i.test(v))
    if (!valid.length) {
      setSourceError('أدخل رابط HTTPS مباشر ينتهي بـ .m3u8 أو .mp4')
      return
    }
    setSource(id, ep, [...playableSources, ...valid])
    setUrl('')
    setSourceError('')
  }
  const removeSources = () => setSource(id, ep, [])

  return (
    <div className="page">
      <h1 className="page-title">{anime ? titleOf(anime) : '...'} — الحلقة {ep}</h1>

      {playableSources.length ? (
        <VideoPlayer key={key + playableSources.join('|')} sources={playableSources} startAt={start} onProgress={onProgress} />
      ) : (
        <div className="player empty-player glass">
          <PlayCircle size={42} />
          <h2>المشغل جاهز — نحتاج رابط بث مرخّص</h2>
          <p className="muted">AniList لا يوفّر ملفات الحلقات نفسها. أضف رابط بث مباشر تملك حق استخدامه، وسيحاول Animeblu الانتقال للمصدر التالي إذا فشل الأول.</p>
        </div>
      )}

      {officialLinks.length > 0 && (
        <section className="official-box glass">
          <div className="section-head"><h2>روابط الحلقة من الناشر</h2></div>
          <p className="muted">هذه روابط رسمية خارجية يوفرها AniList عند توفرها؛ تفتح صفحة الناشر ولا تُشغّل الفيديو داخل مشغل Animeblu.</p>
          {officialLinks.map((item, i) => (
            <a className="official-link" key={item.url + i} href={item.url} target="_blank" rel="noreferrer">
              <span>{item.site || 'المشاهدة لدى الناشر'} — {item.title || `الحلقة ${n}`}</span><ExternalLink size={16} />
            </a>
          ))}
        </section>
      )}

      <form className="src-form glass" onSubmit={addSource}>
        <textarea value={url} onChange={(e) => setUrl(e.target.value)} placeholder={'أضف رابط بث مباشر مرخّص (.m3u8 أو .mp4)\\nيمكن إضافة أكثر من رابط، كل رابط في سطر'} dir="ltr" rows="2" />
        <button className="btn primary" type="submit"><Plus size={17} /> إضافة مصدر</button>
      </form>
      {sourceError && <p className="source-error">{sourceError}</p>}
      {playableSources.length > 0 && (
        <div className="source-management">
          <span>{playableSources.length} مصدر محفوظ لهذه الحلقة</span>
          <button className="btn glass" type="button" onClick={removeSources}><Trash2 size={16}/> حذف المصادر</button>
        </div>
      )}
      <div className="btns">
        {n > 1 && <Link className="btn glass" to={`/watch/${id}/${n - 1}`}>الحلقة السابقة</Link>}
        {(!total || n < total) && <Link className="btn glass" to={`/watch/${id}/${n + 1}`}>الحلقة التالية</Link>}
        {anime && <Link className="btn glass" to={`/anime/${id}`}>صفحة الأنمي</Link>}
      </div>
      {anime && <section className="section"><div className="section-head"><h2>كل الحلقات</h2></div><EpisodeRow anime={anime} /></section>}
    </div>
  )
}
