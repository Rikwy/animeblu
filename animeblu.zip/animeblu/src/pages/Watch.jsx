import { useCallback, useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getAnime, titleOf } from '../api/anilist.js'
import { useApp } from '../context/AppContext.jsx'
import VideoPlayer from '../components/VideoPlayer.jsx'
import EpisodeRow from '../components/EpisodeRow.jsx'

export default function Watch() {
  const { id, ep } = useParams()
  const { sources, setSource, saveProgress, history } = useApp()
  const [anime, setAnime] = useState(null)
  const [file, setFile] = useState({})
  const [url, setUrl] = useState('')

  useEffect(() => { getAnime(id).then(setAnime).catch(() => {}) }, [id])
  useEffect(() => { fetch('/sources.json').then((r) => r.json()).then(setFile).catch(() => {}) }, [])
  useEffect(() => { window.scrollTo(0, 0) }, [id, ep])

  const src = sources[`${id}:${ep}`] || file?.[id]?.[ep] || ''
  const start = history[`${id}:${ep}`]?.time || 0
  const onProgress = useCallback((t, d) => anime && saveProgress(anime, Number(ep), t, d), [anime, ep, saveProgress])

  const n = Number(ep)
  const total = anime?.episodes || 0

  return (
    <div className="page">
      <h1 className="page-title">{anime ? titleOf(anime) : '...'} — الحلقة {ep}</h1>
      {src ? (
        <VideoPlayer key={src} src={src} startAt={start} onProgress={onProgress} />
      ) : (
        <div className="player empty-player glass">
          <p>لا يوجد مصدر فيديو لهذه الحلقة.</p>
          <p className="muted">AniList يوفّر بيانات الأنمي فقط. أضف رابط HLS (.m3u8) أو MP4 للمحتوى الذي تملك حقوقه أو المرخّص لك.</p>
        </div>
      )}
      <form className="src-form glass" onSubmit={(e) => { e.preventDefault(); if (url.trim()) { setSource(id, ep, url.trim()); setUrl('') } }}>
        <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://.../episode.m3u8  أو  .mp4" dir="ltr" />
        <button className="btn primary" type="submit">تعيين المصدر</button>
      </form>
      <div className="btns">
        {n > 1 && <Link className="btn glass" to={`/watch/${id}/${n - 1}`}>الحلقة السابقة</Link>}
        {(!total || n < total) && <Link className="btn glass" to={`/watch/${id}/${n + 1}`}>الحلقة التالية</Link>}
        {anime && <Link className="btn glass" to={`/anime/${id}`}>صفحة الأنمي</Link>}
      </div>
      {anime && <section className="section"><div className="section-head"><h2>كل الحلقات</h2></div><EpisodeRow anime={anime} /></section>}
    </div>
  )
}
