import { useApp } from '../context/AppContext.jsx'
import AnimeCard from '../components/AnimeCard.jsx'

export default function Favorites() {
  const { favorites } = useApp()
  return (
    <div className="page">
      <h1 className="page-title">المفضلة</h1>
      {favorites.length === 0 ? <div className="empty">لم تضف أي أنمي للمفضلة بعد.</div>
        : <div className="grid">{favorites.map((a) => <AnimeCard key={a.id} anime={a} />)}</div>}
    </div>
  )
}
