import { useEffect, useState } from 'react'
import { getHome } from '../api/anilist.js'
import Hero from '../components/Hero.jsx'
import Section from '../components/Section.jsx'
import AnimeCard from '../components/AnimeCard.jsx'
import EpisodeRow from '../components/EpisodeRow.jsx'
import { titleOf } from '../api/anilist.js'

export default function Home() {
  const [data, setData] = useState(null)
  const [hero, setHero] = useState(null)
  const [error, setError] = useState('')

  useEffect(() => {
    document.title = 'Animeblu'
    getHome()
      .then((d) => {
        setData(d)
        setHero(d.trending.find((a) => a.bannerImage) || d.trending[0])
      })
      .catch((e) => setError(e.message))
  }, [])

  const select = (a) => { setHero(a); window.scrollTo({ top: 0, behavior: 'smooth' }) }

  if (error) return <div className="empty">تعذّر الاتصال بـ AniList: {error}</div>
  if (!data) return <div className="hero skeleton" />

  const lists = [
    ['شائع الآن', data.trending],
    ['أنميات الموسم', data.seasonal],
    ['الأعلى تقييماً', data.top],
    ['الأكثر شعبية', data.popular]
  ]
  return (
    <div className="page">
      <Hero anime={hero} />
      <section className="section">
        <div className="section-head"><h2>الحلقات — {titleOf(hero)}</h2></div>
        <EpisodeRow anime={hero} />
      </section>
      {lists.map(([t, items]) => (
        <Section key={t} title={t}>
          {items.map((a) => <AnimeCard key={a.id} anime={a} onSelect={select} active={a.id === hero?.id} />)}
        </Section>
      ))}
    </div>
  )
}
