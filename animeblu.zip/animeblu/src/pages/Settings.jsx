import { useApp } from '../context/AppContext.jsx'

export default function Settings() {
  const { favorites, history, sources, clearAll } = useApp()
  return (
    <div className="page">
      <h1 className="page-title">الإعدادات</h1>
      <div className="info glass col">
        <div><span>المفضلة</span><b>{favorites.length}</b></div>
        <div><span>عناصر السجل</span><b>{Object.keys(history).length}</b></div>
        <div><span>مصادر الفيديو المحفوظة</span><b>{Object.keys(sources).length}</b></div>
        <button className="btn danger" onClick={() => confirm('حذف كل البيانات المحلية؟') && clearAll()}>مسح كل البيانات</button>
      </div>
      <p className="muted">تُحفظ بياناتك في متصفحك فقط. مصادر الحلقات تُضاف من صفحة المشاهدة أو من الملف public/sources.json.</p>
    </div>
  )
}
