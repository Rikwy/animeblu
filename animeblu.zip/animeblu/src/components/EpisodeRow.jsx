import { Link } from 'react-router-dom'
import { Play } from 'lucide-react'
import { useApp } from '../context/AppContext.jsx'

export function buildEpisodes(anime) {
  const se = anime.streamingEpisodes || []
  const total = anime.episodes || se.length || 12
  const count = Math.min(Math.max(total, se.length), 60)
  return Array.from({ length: count }, (_, i) => {
    const s = se[i]
    const raw = s?.title || ''
    const name = raw.replace(/^Episode\s*\d+\s*[-–:]?\s*/i, '').trim()
    return { n: i + 1, title: name || `الحلقة ${i + 1}`, thumb: s?.thumbnail || anime.bannerImage || anime.coverImage?.large }
  })
}

export default function EpisodeRow({ anime }) {
  const { progressOf } = useApp()
  const eps = buildEpisodes(anime)
  return (
    <div className="row eps">
      {eps.map((e) => {
        const p = progressOf(anime.id, e.n)
        return (
          <Link key={e.n} to={`/watch/${anime.id}/${e.n}`} className="ep glass">
            <div className="ep-img">
              <img src={e.thumb} alt="" loading="lazy" />
              <span className="ep-play"><Play size={18} fill="#fff" /></span>
              <div className="bar"><i style={{ width: p + '%' }} /></div>
            </div>
            <div className="ep-info"><b>الحلقة {e.n}</b><span>{e.title}</span></div>
          </Link>
        )
      })}
    </div>
  )
}
