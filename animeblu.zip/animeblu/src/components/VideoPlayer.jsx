import { useEffect, useRef, useState } from 'react'
import Hls from 'hls.js'

export default function VideoPlayer({ sources = [], startAt = 0, onProgress }) {
  const ref = useRef(null)
  const [index, setIndex] = useState(0)
  const [err, setErr] = useState('')
  const list = (Array.isArray(sources) ? sources : [sources]).filter(Boolean)

  useEffect(() => { setIndex(0); setErr('') }, [list.join('|')])

  useEffect(() => {
    const video = ref.current
    const src = list[index]
    if (!video || !src) return
    let hls
    let failed = false
    const fail = (message) => {
      if (failed) return
      failed = true
      if (index + 1 < list.length) {
        setErr(`تعذّر المصدر ${index + 1}، جارٍ تجربة المصدر البديل…`)
        setTimeout(() => setIndex((i) => Math.min(i + 1, list.length - 1)), 250)
      } else setErr(message || 'تعذّر تشغيل جميع المصادر. تحقق من صلاحية الروابط ودعم CORS.')
    }
    const seek = () => { if (startAt > 5 && Number.isFinite(video.duration)) video.currentTime = Math.min(startAt, video.duration - 1) }
    const onVideoError = () => fail('تعذّر تشغيل جميع المصادر. قد يكون الرابط منتهياً أو يمنع التشغيل داخل الموقع.')
    video.addEventListener('error', onVideoError)
    setErr('')
    if (/\.m3u8(?:$|[?#])/i.test(src)) {
      if (Hls.isSupported()) {
        hls = new Hls({ enableWorker: true, backBufferLength: 30 })
        hls.loadSource(src)
        hls.attachMedia(video)
        hls.on(Hls.Events.MANIFEST_PARSED, seek)
        hls.on(Hls.Events.ERROR, (_, data) => { if (data.fatal) fail('تعذّر تحميل بث HLS. قد تكون سياسة CORS أو صلاحية المصدر هي السبب.') })
      } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = src
        video.addEventListener('loadedmetadata', seek, { once: true })
      } else fail('هذا المتصفح لا يدعم تشغيل HLS.')
    } else {
      video.src = src
      video.addEventListener('loadedmetadata', seek, { once: true })
    }
    return () => {
      video.removeEventListener('error', onVideoError)
      hls?.destroy()
      video.pause()
      video.removeAttribute('src')
      video.load()
    }
  }, [list.join('|'), index]) // source list is intentionally serialized

  useEffect(() => {
    const video = ref.current
    if (!video) return
    let last = 0
    const tick = () => {
      if (Date.now() - last > 4000 && video.duration) {
        last = Date.now()
        onProgress?.(video.currentTime, video.duration)
      }
    }
    const save = () => video.duration && onProgress?.(video.currentTime, video.duration)
    video.addEventListener('timeupdate', tick)
    video.addEventListener('pause', save)
    return () => {
      video.removeEventListener('timeupdate', tick)
      video.removeEventListener('pause', save)
    }
  }, [onProgress])

  if (!list.length) return null
  return (
    <div className="player">
      <video ref={ref} controls playsInline preload="metadata" />
      {list.length > 1 && <div className="player-source">المصدر {Math.min(index + 1, list.length)} من {list.length}</div>}
      {err && <div className="player-err">{err}</div>}
    </div>
  )
}
