import { useEffect, useRef, useState } from 'react'
import Hls from 'hls.js'

export default function VideoPlayer({ src, startAt = 0, onProgress, onFatal }) {
  const ref = useRef(null)
  const [err, setErr] = useState('')

  useEffect(() => {
    const v = ref.current
    if (!v || !src) return
    setErr('')
    let hls
    let failed = false
    const failOnce = () => { if (failed) return; failed = true; setErr('تعذّر تشغيل هذا المصدر. جارٍ تجربة المصدر التالي…'); onFatal?.() }
    const seek = () => { if (startAt > 5) v.currentTime = startAt }
    if (/\.m3u8(\?|$)/i.test(src)) {
      if (Hls.isSupported()) {
        hls = new Hls()
        hls.loadSource(src)
        hls.attachMedia(v)
        hls.on(Hls.Events.MANIFEST_PARSED, seek)
        hls.on(Hls.Events.ERROR, (_, d) => { if (d.fatal) failOnce() })
      } else if (v.canPlayType('application/vnd.apple.mpegurl')) {
        v.src = src
        v.addEventListener('loadedmetadata', seek, { once: true })
      } else setErr('المتصفح لا يدعم HLS.')
    } else {
      v.src = src
      v.addEventListener('loadedmetadata', seek, { once: true })
    }
    const handleMediaError = () => failOnce()
    v.addEventListener('error', handleMediaError)
    return () => { hls?.destroy(); v.removeEventListener('error', handleMediaError); v.removeAttribute('src'); v.load() }
  }, [src, onFatal]) // eslint-disable-line

  useEffect(() => {
    const v = ref.current
    if (!v) return
    let last = 0
    const tick = () => {
      if (Date.now() - last > 4000 && v.duration) { last = Date.now(); onProgress?.(v.currentTime, v.duration) }
    }
    const save = () => v.duration && onProgress?.(v.currentTime, v.duration)
    v.addEventListener('timeupdate', tick)
    v.addEventListener('pause', save)
    return () => { v.removeEventListener('timeupdate', tick); v.removeEventListener('pause', save) }
  }, [onProgress])

  return (
    <div className="player">
      <video ref={ref} controls playsInline preload="metadata"  />
      {err && <div className="player-err">{err}</div>}
    </div>
  )
}
