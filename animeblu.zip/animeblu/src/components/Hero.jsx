import { Link } from 'react-router-dom'
import { Play, Heart, Star, Info } from 'lucide-react'
import { useApp } from '../context/AppContext.jsx'
import { titleOf, scoreOf, cleanDesc } from '../api/anilist.js'

export default function Hero({ anime }) {
  const { isFav, toggleFav, history } = useApp()
  if (!anime) return <div className="hero skeleton" />
  const bg = anime.bannerImage || anime.coverImage?.extraLarge
  const fav = isFav(anime.id)
  const last = Object.values(history).filter((h) => h.anime.id === anime.id).sort((a, b) => b.updatedAt - a.updatedAt)[0]
  const ep = last?.ep || 1

  return (
    <div className="hero">
      <img key={bg} className="hero-bg" src={bg} alt="" />
      <div className="hero-shade" />
      <div className="hero-content">
        <div className="meta">
          {scoreOf(anime) && <span className="chip"><Star size={14} fill="#fbbf24" color="#fbbf24" />{scoreOf(anime)}</span>}
          {anime.seasonYear && <span className="chip">{anime.seasonYear}</span>}
          {anime.episodes && <span className="chip">{anime.episodes} حلقة</span>}
          {anime.genres?.slice(0, 2).map((g) => <span key={g} className="chip">{g}</span>)}
        </div>
        <h1 dir="auto">{titleOf(anime)}</h1>
        <p className="desc" dir="auto">{cleanDesc(anime.description)}</p>
        <div className="btns">
          <Link to={`/watch/${anime.id}/${ep}`} className="btn primary"><Play size={18} fill="#fff" />{last ? 'متابعة المشاهدة' : 'مشاهدة الآن'}</Link>
          <button className={'btn glass' + (fav ? ' on' : '')} onClick={() => toggleFav(anime)}>
            <Heart size={18} fill={fav ? 'currentColor' : 'none'} />{fav ? 'في المفضلة' : 'إضافة للمفضلة'}
          </button>
          <Link to={`/anime/${anime.id}`} className="btn glass"><Info size={18} />التفاصيل</Link>
        </div>
      </div>
    </div>
  )
}
