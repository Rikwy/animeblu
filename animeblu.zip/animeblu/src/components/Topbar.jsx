import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Search, Bell, User } from 'lucide-react'
import { useApp } from '../context/AppContext.jsx'
import { titleOf } from '../api/anilist.js'

export default function Topbar() {
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(null)
  const nav = useNavigate()
  const { history, favorites } = useApp()
  const recent = Object.values(history).sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 5)

  const submit = (e) => {
    e.preventDefault()
    if (q.trim()) nav(`/search?q=${encodeURIComponent(q.trim())}`)
  }
  const toggle = (k) => setOpen((o) => (o === k ? null : k))

  return (
    <header className="topbar">
      <form className="search glass" onSubmit={submit}>
        <Search size={18} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث عن أنمي..." />
      </form>
      <div className="top-actions">
        <div className="pop-wrap">
          <button className="icon-btn glass" onClick={() => toggle('n')} aria-label="الإشعارات">
            <Bell size={18} />{recent.length > 0 && <i className="dot" />}
          </button>
          {open === 'n' && (
            <div className="popover glass" onClick={() => setOpen(null)}>
              <h4>تابع المشاهدة</h4>
              {recent.length === 0 && <p className="muted">لا توجد إشعارات بعد.</p>}
              {recent.map((h) => (
                <Link key={h.anime.id + ':' + h.ep} to={`/watch/${h.anime.id}/${h.ep}`} className="pop-item">
                  {titleOf(h.anime)} — حلقة {h.ep}
                </Link>
              ))}
            </div>
          )}
        </div>
        <div className="pop-wrap">
          <button className="icon-btn glass" onClick={() => toggle('p')} aria-label="الملف الشخصي"><User size={18} /></button>
          {open === 'p' && (
            <div className="popover glass" onClick={() => setOpen(null)}>
              <h4>حسابي</h4>
              <Link to="/favorites" className="pop-item">المفضلة ({favorites.length})</Link>
              <Link to="/history" className="pop-item">سجل المشاهدة</Link>
              <Link to="/settings" className="pop-item">الإعدادات</Link>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
