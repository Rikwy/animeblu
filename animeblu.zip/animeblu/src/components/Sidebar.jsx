import { NavLink } from 'react-router-dom'
import { Home, Compass, Flame, Heart, History, Settings, Play } from 'lucide-react'

const items = [
  { to: '/', label: 'الرئيسية', icon: Home },
  { to: '/explore', label: 'استكشاف الأنمي', icon: Compass },
  { to: '/popular', label: 'الأكثر مشاهدة', icon: Flame },
  { to: '/favorites', label: 'المفضلة', icon: Heart },
  { to: '/history', label: 'سجل المشاهدة', icon: History },
  { to: '/settings', label: 'الإعدادات', icon: Settings }
]

export default function Sidebar() {
  return (
    <aside className="sidebar glass">
      <NavLink to="/" className="logo">
        <span className="logo-mark"><Play size={16} fill="#fff" /></span>
        <span className="logo-text">Anime<b>blu</b></span>
      </NavLink>
      <nav>
        {items.map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => 'nav-item' + (isActive ? ' active' : '')}>
            <Icon size={20} /><span>{label}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
