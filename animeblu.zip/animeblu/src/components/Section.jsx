export default function Section({ title, children, action }) {
  return (
    <section className="section">
      <div className="section-head"><h2>{title}</h2>{action}</div>
      <div className="row">{children}</div>
    </section>
  )
}
