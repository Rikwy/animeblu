import { Link } from 'react-router-dom'
import { Star } from 'lucide-react'
import { titleOf, scoreOf } from '../api/anilist.js'

export default function AnimeCard({ anime, onSelect, active }) {
  const body = (
    <>
      <div className="poster" style={{ background: anime.coverImage?.color || '#2a1a55' }}>
        <img src={anime.coverImage?.large} alt={titleOf(anime)} loading="lazy" />
        {scoreOf(anime) && <span className="badge"><Star size={12} fill="currentColor" />{scoreOf(anime)}</span>}
      </div>
      <h4>{titleOf(anime)}</h4>
      <p>{anime.seasonYear || ''}{anime.format ? ` · ${anime.format}` : ''}</p>
    </>
  )
  return onSelect ? (
    <button className={'card' + (active ? ' active' : '')} onClick={() => onSelect(anime)}>{body}</button>
  ) : (
    <Link to={`/anime/${anime.id}`} className="card">{body}</Link>
  )
}
