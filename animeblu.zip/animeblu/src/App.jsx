import { Routes, Route } from 'react-router-dom'
import Sidebar from './components/Sidebar.jsx'
import Topbar from './components/Topbar.jsx'
import Home from './pages/Home.jsx'
import Explore from './pages/Explore.jsx'
import Detail from './pages/Detail.jsx'
import Watch from './pages/Watch.jsx'
import Favorites from './pages/Favorites.jsx'
import History from './pages/History.jsx'
import Settings from './pages/Settings.jsx'

export default function App() {
  return (
    <div className="shell">
      <div className="glow g1" /><div className="glow g2" />
      <Sidebar />
      <div className="main">
        <Topbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/explore" element={<Explore mode="explore" />} />
          <Route path="/popular" element={<Explore mode="popular" />} />
          <Route path="/search" element={<Explore mode="search" />} />
          <Route path="/anime/:id" element={<Detail />} />
          <Route path="/watch/:id/:ep" element={<Watch />} />
          <Route path="/favorites" element={<Favorites />} />
          <Route path="/history" element={<History />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="*" element={<div className="empty">الصفحة غير موجودة</div>} />
        </Routes>
      </div>
    </div>
  )
}
