import { createContext, useContext, useEffect, useState, useCallback } from 'react'

const Ctx = createContext(null)
export const useApp = () => useContext(Ctx)

function load(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback } catch { return fallback }
}
const mini = (a) => ({
  id: a.id, title: a.title, coverImage: a.coverImage, bannerImage: a.bannerImage,
  averageScore: a.averageScore, seasonYear: a.seasonYear, episodes: a.episodes
})

export function AppProvider({ children }) {
  const [favorites, setFavorites] = useState(() => load('animeblu:favorites', []))
  const [history, setHistory] = useState(() => load('animeblu:history', {}))
  const [sources, setSources] = useState(() => load('animeblu:sources', {}))

  useEffect(() => localStorage.setItem('animeblu:favorites', JSON.stringify(favorites)), [favorites])
  useEffect(() => localStorage.setItem('animeblu:history', JSON.stringify(history)), [history])
  useEffect(() => localStorage.setItem('animeblu:sources', JSON.stringify(sources)), [sources])

  const isFav = useCallback((id) => favorites.some((f) => f.id === id), [favorites])
  const toggleFav = (a) =>
    setFavorites((f) => (f.some((x) => x.id === a.id) ? f.filter((x) => x.id !== a.id) : [mini(a), ...f]))

  const saveProgress = useCallback((anime, ep, time, duration) => {
    setHistory((h) => ({ ...h, [`${anime.id}:${ep}`]: { anime: mini(anime), ep, time, duration, updatedAt: Date.now() } }))
  }, [])
  const progressOf = (id, ep) => {
    const h = history[`${id}:${ep}`]
    return h && h.duration ? Math.min(100, (h.time / h.duration) * 100) : 0
  }
  const setSource = (id, ep, url) => setSources((s) => {
    const key = `${id}:${ep}`
    const current = s[key] == null ? [] : (Array.isArray(s[key]) ? s[key] : [s[key]])
    return { ...s, [key]: [...new Set([...current, url])] }
  })
  const clearAll = () => { setFavorites([]); setHistory({}); setSources({}) }

  return (
    <Ctx.Provider value={{ favorites, isFav, toggleFav, history, saveProgress, progressOf, sources, setSource, clearAll }}>
      {children}
    </Ctx.Provider>
  )
}
