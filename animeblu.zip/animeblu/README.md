# Animeblu

منصة أنمي بتصميم سينمائي (React + Vite + AniList GraphQL + hls.js).

## التشغيل
```bash
npm install
npm run dev
```

## البناء
```bash
npm run build
npm run preview
```

## النشر على Render
1. ارفع المشروع إلى GitHub.
2. في Render اختر **New → Blueprint** وحدّد المستودع (يقرأ `render.yaml` تلقائياً)،
   أو أنشئ **Static Site** بالأمر `npm install && npm run build` والمجلد `dist`، وأضف Rewrite من `/*` إلى `/index.html`.

## مصادر الفيديو
AniList يوفّر بيانات الأنمي فقط. لتشغيل الحلقات استخدم روابط HLS (`.m3u8`) أو MP4 **المرخّصة أو التي تملك حقوقها**:
- من صفحة المشاهدة (حقل «تعيين المصدر»، يُحفظ في المتصفح)، أو
- من الملف `public/sources.json` بالصيغة `{ "anilistId": { "1": "https://..." } }`.

ملاحظة: يجب أن يسمح خادم الفيديو بـ CORS لنطاق موقعك.
