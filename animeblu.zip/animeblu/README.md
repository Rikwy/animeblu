# Animeblu

Animeblu is a React/Vite anime catalog using AniList metadata.

## Playback and legal availability

AniList provides anime metadata and may list promotional streaming previews; it does not provide full-episode playback URLs. The Watch page now offers a Saudi Arabia availability search through JustWatch and labels AniList streaming entries as previews. It does not scrape streaming services, bypass subscriptions, or claim that a preview is a full episode.

For content you own or are licensed to stream, add one or more direct HLS (`.m3u8`) or MP4 URLs to `public/sources.json` using the anime's AniList ID and episode number. Animeblu tries the listed URLs in order and moves to the next when playback fails. Example:

```json
{
  "16498": {
    "1": [
      "https://your-authorized-host.example/episode-1.m3u8",
      "https://backup-authorized-host.example/episode-1.mp4"
    ]
  }
}
```

You can also enter authorized direct media URLs in the Watch page; these are saved in the browser for that user.

## Build

```bash
npm install
npm run build
```

Publish directory for Render Static Site: `dist`.
